/* widgets/toggleButton/widget.js */

//don't forget, we can accept arguments passed to the controller
//when the controller is initialized/instantiated via code

//recall this statement means:
//   1) either take what was passed to the controller (arguments[0]) and store that into args
//   2) OR, create an empty object and store that into args
var args = arguments[0] || {};

//set a default state to the button to either
//   1) what was passed to the controller,
//   2) OR, a default value: "on"
args.defaultState = args.defaultState || "on";

//set the initial state of the button
if(args.defaultState === "on")
{
	//remember, this is a toggle, so we change the label
	//to reflect the state you'd like to switch to
	toggleButtonByIdClicked("off");
}else if(args.defaultState === "off")
{
	//same as above about state switching
	toggleButtonByIdClicked("on");	
}

//create an event-handler for when the user clicks the button
$.container.addEventListener("click", function(_event)
	{
		//hide the clicked item, show the unclicked one
		toggleButtonByIdClicked(_event.source.id);		
	}
); //book bug: missing semi

//_buttonId name of the id of the UI control clicked
function toggleButtonByIdClicked(_buttonId)
{
	//a refresher/primer on === vs. == in JS
	//http://www.w3schools.com/js/js_comparisons.asp
	if(_buttonId === "on")
	{
		//remember the $ accesses controls in the view
		$.on.hide();
		$.off.show();
	}else if(_buttonId === "off")
	{
		$.on.show();
		$.off.hide();
	}
}


